using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace team13
{
    public class ObjectInteraction : MonoBehaviour
    {
        public float pauseTime = 2f; // Adjust this value to set the pause time
        private bool isClickable = true;

        void OnMouseDown()
        {
            if (isClickable)
            {
                // Handle click event
                GameManager.instance.ObjectClicked(gameObject);

                // Make the object disappear
                Destroy(gameObject);
            }
        }

        public void SetClickable(bool clickable)
        {
            isClickable = clickable;
        }
    }
}
