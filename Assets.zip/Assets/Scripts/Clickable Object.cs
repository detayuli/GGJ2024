using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace team13
{
    public class ClickableObject : MonoBehaviour
    {
        public float speed;

        // Update is called once per frame
        void Update()
        {
            // Move the object in the same direction as the scrolling background
            transform.Translate(Vector2.left * speed * Time.deltaTime);
        }

        private void OnMouseDown()
        {
            // Handle click event here
            Debug.Log("Object Clicked!");

            // You can add more behavior or functionality when the object is clicked
        }
    }
}